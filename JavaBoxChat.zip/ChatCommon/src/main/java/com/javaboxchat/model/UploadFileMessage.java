package com.javaboxchat.model;

public class UploadFileMessage {

    private String type;
    private String sender;
    private String receiver;
    private String fileName;

    public UploadFileMessage(
            String type,
            String sender,
            String receiver,
            String fileName
    ) {
        this.type = type;
        this.sender = sender;
        this.receiver = receiver;
        this.fileName = fileName;
    }

    public String getType() {
        return type;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public String getFileName() {
        return fileName;
    }
}